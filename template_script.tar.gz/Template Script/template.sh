#!/bin/bash
#set -e

#
# 	Script <scriptName> (c)2012 - Version <scriptVersion>
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.
#	
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	NO ALTERAR EL SCRIPT, DE LO CONTRARIO EL MISMO DEJARA DE FUNCIONAR
#
#		 Autor: Garcia Vazquez, Manuel Andres
#		Correo: mvazquez@me.com
#		   Web: www.scabb-island.com.ar
#		gitHub: https://github.com/mgvazquez/<scriptName>
#		Issues: https://github.com/mgvazquez/<scriptName>/issues
#
#		   Uso: <USO>
#
#		  Nota: <NOTA>
# 

############## VARIABLES / CONSTANTES ##############
	DATE=`date "+%Y.%m.%d"`
	HOST_NAME=$(hostname | awk -F '.' '{print $1}') # Nombre del Host

	# --- Carga el archivo de configuracion ---
	if [[ ( ( $# -eq 0 ) || ( $# -gt 0 && "$1" != *".config" ) ) && -f "${0%.*}.config" ]]; then
		. ${0%.*}.config
	elif [[ $# -gt 0 && "$1" == *".config" && -f "$1" ]]; then
		. $1
	else
		/usr/bin/clear
		echo -e "WARN: No se encontro el archivo de configuración, se cargan opciones por defecto." && /bin/sleep 5	
	fi
	
	#--- Carga Librerias ---
	LIBRARY_PATH=${LIBRARY_PATH:-/usr/lib/lsb}
	if [[ -f $LIBRARY_PATH/scabblibrary.lib ]]; then
		. $LIBRARY_PATH/scabblibrary.lib
	else
		/usr/bin/clear && echo -e "ERROR: No se encontro la libreria 'scabblibrary.lib' (http://github.com/mgvazquez/scabblibrary) en '$LIBRARY_PATH'."
		exit 1
	fi

	SCRIPT_VERSION="0.1"
####################################################


#################### FUNCIONES #####################

####################################################


####################### MAIN #######################
	chkScriptIntegrity;
	chkScriptVersion;
	echo "$SCRIPT_TITLE" | log
	exit 0;
####################################################
